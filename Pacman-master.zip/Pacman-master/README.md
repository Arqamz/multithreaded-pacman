# Pacman
Pacman in C++ using SFML

I implmented most of the mechanics, graphics, and audio as they were in the original arcade game

Video of me playing:
https://www.youtube.com/watch?v=Ju1932L9phM
